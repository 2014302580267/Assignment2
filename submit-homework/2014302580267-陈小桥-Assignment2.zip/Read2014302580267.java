import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class Read2014302580267 {
	File f;
	
	public void readHtml(){
		this.f=new File("C:/Users/cxq/Desktop/��ʦ��ҳ.html");
		HttpRequest response=HttpRequest.get("http://www.lingnan.sysu.edu.cn/lnshizi/faculty_vch.asp?name=chengang");
		if(response.ok())
			response.receive(f);
	}
	
	
	
	public void writeHtml() throws IOException{
		FileWriter w=new FileWriter(new File("C:/Users/cxq/Desktop/��ʦ��ҳ.txt"));
		
		
		Document doc=Jsoup.parse(this.f,"UTF-8");
		
		w.write("��ʦ���");
		Element about=doc.getElementsByTag("body").get(0).getElementById("about1");
		for(Element ele:about.getElementsByTag("p")){
			String s=ele.text().replaceAll(" ","");
			if(!(s.isEmpty()))
			w.write(ele.text()+"\n");
		}
		
		Elements table=doc.getElementsByTag("table");
		Elements brief=table.get(0).getElementsByTag("tr");		
		for(Element ele:brief.get(0).getElementsByTag("tr")){
			boolean b=false;
			for(Element elem:ele.getElementsByTag("td")){
				if(elem.text().trim().matches("(\\w)+(\\.\\w+)*@(\\w)+((\\.\\w{2,}){1,4})")){
					w.write("���䣺"+elem.text()+"\n");
					b=true;
				}
			}
			if(b)break;
		}
		for(Element ele:brief.get(0).getElementsByTag("tr")){
			boolean b=false;
			for(Element elem:ele.getElementsByTag("td")){
				
				if(elem.text().trim().matches("([0-9]{2})+(\\-)+([0-9]{2})+(\\-)+([0-9]{8})")){
					w.write("�칫�绰��"+elem.text()+"\n");
					b=true;
				}
			}
			if(b)break;
		}
		w.flush();
        w.close();
	}
	
	public static void main(String[]args) throws IOException{
		Read2014302580267 read = new Read2014302580267();
		read.readHtml();
		read.writeHtml();
	}
}